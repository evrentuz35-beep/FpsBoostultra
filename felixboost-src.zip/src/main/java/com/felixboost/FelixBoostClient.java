package com.felixboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FelixBoostClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("FelixBoost");
    private static boolean applied;

    @Override
    public void onInitializeClient() {
        FelixConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            GameOptions o = client.options;
            if (o == null) return;
            FelixConfig cfg = FelixConfig.get();

            if (!applied) {
                applied = true;
                if (cfg.applyFastSettings) applyFastSettings(o);
            }

            // Render mesafesini zorla (oyun ici menuden degistirilse bile geri alinir)
            if (cfg.forceViewDistance > 0) {
                int want = Math.max(2, cfg.forceViewDistance);
                if (o.getViewDistance().getValue() != want) o.getViewDistance().setValue(want);
            }
        });

        LOGGER.info("FelixBoost yuklendi");
    }

    /** Oyun acilisinda bir kez uygulanir; sonra oyun icinden degistirebilirsin. */
    private static void applyFastSettings(GameOptions o) {
        try {
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getEntityShadows().setValue(false);
            o.getBiomeBlendRadius().setValue(0);
            o.getEntityDistanceScaling().setValue(0.5D);
            o.getAo().setValue(false);
            o.getEnableVsync().setValue(false);
            o.getMaxFps().setValue(260);
            o.getMipmapLevels().setValue(0);
            o.getSimulationDistance().setValue(5);
            o.getFovEffectScale().setValue(0.0D);
            o.write();
            LOGGER.info("Hizli grafik ayarlari uygulandi");
        } catch (Throwable t) {
            LOGGER.warn("Grafik ayarlari uygulanamadi", t);
        }
    }
}
