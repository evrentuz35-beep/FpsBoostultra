package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {

    /** Hasar alan varligin kirmizi parlamasini kaldir. */
    @Inject(method = "getOverlay", at = @At("HEAD"), cancellable = true)
    private static void felixboost$noHurtFlash(CallbackInfoReturnable<Integer> cir) {
        if (FelixConfig.get().noHitAnimation) cir.setReturnValue(OverlayTexture.DEFAULT_UV);
    }
}
