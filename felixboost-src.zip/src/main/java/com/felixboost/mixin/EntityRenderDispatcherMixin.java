package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    /** Cok uzaktaki entity'leri hic cizme. (x, y, z = kamera konumu) */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void felixboost$cullFarEntities(Entity entity, Frustum frustum, double x, double y, double z,
                                            CallbackInfoReturnable<Boolean> cir) {
        FelixConfig cfg = FelixConfig.get();
        if (!cfg.entityCulling) return;

        if (entity instanceof PlayerEntity || entity instanceof EnderDragonEntity || entity instanceof WitherEntity) return;
        if (entity == MinecraftClient.getInstance().cameraEntity || entity.isGlowing()) return;

        double dx = entity.getX() - x;
        double dy = entity.getY() - y;
        double dz = entity.getZ() - z;
        double limit = entity instanceof LivingEntity ? cfg.entityDistanceSq
                : Math.min(cfg.entityDistanceSq, cfg.smallEntityDistanceSq);
        if (dx * dx + dy * dy + dz * dz > limit) {
            cir.setReturnValue(false);
        }
    }
}
