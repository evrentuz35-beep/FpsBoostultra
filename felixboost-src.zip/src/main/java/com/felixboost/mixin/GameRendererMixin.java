package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    /** Hasar alinca kameranin sarsilmasini kapat. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void felixboost$noHurtTilt(CallbackInfo ci) {
        if (FelixConfig.get().noHitAnimation) ci.cancel();
    }
}
