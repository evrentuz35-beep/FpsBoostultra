package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    /** El sallama (vurus) animasyonunu sifirla. */
    @Inject(method = "getHandSwingProgress", at = @At("HEAD"), cancellable = true)
    private void felixboost$noSwing(CallbackInfoReturnable<Float> cir) {
        if (FelixConfig.get().noHitAnimation) cir.setReturnValue(0.0F);
    }
}
