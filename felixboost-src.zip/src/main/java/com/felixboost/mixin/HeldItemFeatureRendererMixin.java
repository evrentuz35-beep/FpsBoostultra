package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemFeatureRenderer.class)
public class HeldItemFeatureRendererMixin {

    /** Ucuncu sahis gorunumde oyuncularin/mobların elindeki itemi cizme. */
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void felixboost$noHeldItems(CallbackInfo ci) {
        if (FelixConfig.get().noHeldItems) ci.cancel();
    }
}
