package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.ThreadLocalRandom;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    /** Uzaktaki parcaciklari at, yakindakilerin bir kismini seyrelt. */
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void felixboost$limitParticles(ParticleEffect parameters, double x, double y, double z,
                                           double velocityX, double velocityY, double velocityZ,
                                           CallbackInfoReturnable<Particle> cir) {
        FelixConfig cfg = FelixConfig.get();
        if (cfg.noParticles) {
            cir.setReturnValue(null);
            return;
        }
        if (!cfg.particleLimit) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            double dx = x - cam.x, dy = y - cam.y, dz = z - cam.z;
            if (dx * dx + dy * dy + dz * dz > cfg.particleDistanceSq) {
                cir.setReturnValue(null);
                return;
            }
        }
        if (cfg.particleKeepPercent < 100 && ThreadLocalRandom.current().nextInt(100) >= cfg.particleKeepPercent) {
            cir.setReturnValue(null);
        }
    }

    /** Hazir Particle nesnesi eklenen yol (blok kirma parcaciklari vb.). */
    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void felixboost$noParticleObjects(CallbackInfo ci) {
        if (FelixConfig.get().noParticles) ci.cancel();
    }

    /** Emitter parcaciklari (kritik, buyulu vurus vb.). Iki asiri yukleme de yakalanir. */
    @Inject(method = "addEmitter", at = @At("HEAD"), cancellable = true)
    private void felixboost$noEmitters(CallbackInfo ci) {
        if (FelixConfig.get().noParticles) ci.cancel();
    }
}
