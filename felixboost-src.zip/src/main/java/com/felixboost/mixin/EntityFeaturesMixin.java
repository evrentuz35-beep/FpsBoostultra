package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.feature.Deadmau5FeatureRenderer;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.client.render.entity.feature.HeadFeatureRenderer;
import net.minecraft.client.render.entity.feature.ShoulderParrotFeatureRenderer;
import net.minecraft.client.render.entity.feature.StuckObjectsFeatureRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Zirh, pelerin, elytra, kafa itemi, saplanmis oklar, papagan ve kulak cizimlerini tek yerden kapatir. */
@Mixin({
        ArmorFeatureRenderer.class,
        CapeFeatureRenderer.class,
        Deadmau5FeatureRenderer.class,
        ElytraFeatureRenderer.class,
        HeadFeatureRenderer.class,
        ShoulderParrotFeatureRenderer.class,
        StuckObjectsFeatureRenderer.class
})
public class EntityFeaturesMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void felixboost$noFeatures(CallbackInfo ci) {
        if (FelixConfig.get().noEntityFeatures) ci.cancel();
    }
}
