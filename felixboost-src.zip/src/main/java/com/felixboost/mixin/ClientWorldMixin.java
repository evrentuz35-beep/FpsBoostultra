package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {

    /** Cok uzaktaki varliklari istemci tarafinda tick'leme. Binek/yolcu ve oyuncular haric. */
    @Inject(method = "tickEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void felixboost$skipFarTicks(Entity entity, CallbackInfo ci) {
        FelixConfig cfg = FelixConfig.get();
        if (!cfg.skipFarEntityTicks) return;

        ClientPlayerEntity self = MinecraftClient.getInstance().player;
        if (self == null || entity == self || entity instanceof PlayerEntity) return;
        if (entity.hasVehicle() || entity.hasPassengers()) return;

        if (entity.squaredDistanceTo(self) > cfg.farTickDistanceSq) ci.cancel();
    }
}
