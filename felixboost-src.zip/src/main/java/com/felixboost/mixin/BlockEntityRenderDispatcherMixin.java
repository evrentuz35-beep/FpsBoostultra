package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.EndGatewayBlockEntity;
import net.minecraft.block.entity.EndPortalBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntityRenderDispatcher.class)
public class BlockEntityRenderDispatcherMixin {

    /** Uzaktaki sandik, tabela, ocak vb. block entity'leri cizme. */
    @Inject(method = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
            at = @At("HEAD"), cancellable = true)
    private void felixboost$cullFarBlockEntities(BlockEntity blockEntity, float tickDelta, MatrixStack matrices,
                                                 VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
        FelixConfig cfg = FelixConfig.get();
        if (!cfg.blockEntityCulling) return;

        // Isin/portal efektleri uzaktan da gorunmeli
        if (blockEntity instanceof BeaconBlockEntity || blockEntity instanceof EndGatewayBlockEntity
                || blockEntity instanceof EndPortalBlockEntity) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        BlockPos pos = blockEntity.getPos();
        double dx = pos.getX() + 0.5 - cam.x;
        double dy = pos.getY() + 0.5 - cam.y;
        double dz = pos.getZ() + 0.5 - cam.z;
        if (dx * dx + dy * dy + dz * dz > cfg.blockEntityDistanceSq) {
            ci.cancel();
        }
    }
}
