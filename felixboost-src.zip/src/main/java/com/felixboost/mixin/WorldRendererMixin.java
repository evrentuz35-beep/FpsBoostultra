package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    /** Gokyuzu cizimini atla (gunes, ay, yildiz, gokyuzu kubbesi). */
    @Inject(method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V",
            at = @At("HEAD"), cancellable = true)
    private void felixboost$skipSky(MatrixStack matrices, Matrix4f projectionMatrix, float tickDelta, Camera camera,
                                    boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        if (FelixConfig.get().disableSky) ci.cancel();
    }

    /** Bulut cizimini atla. */
    @Inject(method = "renderClouds(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FDDD)V",
            at = @At("HEAD"), cancellable = true)
    private void felixboost$skipClouds(MatrixStack matrices, Matrix4f projectionMatrix, float tickDelta,
                                       double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        if (FelixConfig.get().disableClouds) ci.cancel();
    }

    /** Yagmur/kar cizimini atla. */
    @Inject(method = "renderWeather(Lnet/minecraft/client/render/LightmapTextureManager;FDDD)V",
            at = @At("HEAD"), cancellable = true)
    private void felixboost$skipWeather(LightmapTextureManager manager, float tickDelta,
                                        double cameraX, double cameraY, double cameraZ, CallbackInfo ci) {
        if (FelixConfig.get().disableWeather) ci.cancel();
    }
}
