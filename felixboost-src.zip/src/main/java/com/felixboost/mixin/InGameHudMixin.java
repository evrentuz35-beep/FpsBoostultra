package com.felixboost.mixin;

import com.felixboost.FelixConfig;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    /** Ekran ortasindaki buyuk title yazisini gosterme. */
    @Inject(method = "setTitle", at = @At("HEAD"), cancellable = true)
    private void felixboost$noTitle(CallbackInfo ci) {
        if (FelixConfig.get().noTitles) ci.cancel();
    }

    /** Altindaki subtitle yazisini gosterme. */
    @Inject(method = "setSubtitle", at = @At("HEAD"), cancellable = true)
    private void felixboost$noSubtitle(CallbackInfo ci) {
        if (FelixConfig.get().noTitles) ci.cancel();
    }
}
