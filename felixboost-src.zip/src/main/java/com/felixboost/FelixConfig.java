package com.felixboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** config/felixboost.json dosyasindan okunan ayarlar. Mesafeler blok cinsindendir. */
public class FelixConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static FelixConfig instance;

    public boolean entityCulling = true;
    public int entityDistance = 32;

    public boolean blockEntityCulling = true;
    public int blockEntityDistance = 32;

    public boolean particleLimit = true;
    public int particleDistance = 32;
    /** Yakin parcaciklardan yuzde kaci cizilsin (100 = hepsi). */
    public int particleKeepPercent = 60;

    /** Gokyuzunu (gunes, ay, yildiz) hic cizme; arka plan sis rengi kalir. */
    public boolean disableSky = true;
    public boolean disableClouds = true;
    /** Yagmur/kar cizimini kapatir (kapali = hala cizilir). */
    public boolean disableWeather = true;

    /** Oyun acilisinda hizli grafik ayarlarini bir kez uygular (hizli grafik, parcacik minimal, golge kapali...). */
    public boolean applyFastSettings = true;

    /** Hicbir parcacik cizilmez (kirilma, duman, kritik vurus...). */
    public boolean noParticles = true;
    /** Ucuncu sahis gorunumde kimsenin elindeki item cizilmez. */
    public boolean noHeldItems = true;
    /** Vurus animasyonlari: hasar sarsintisi, kirmizi hasar rengi, el sallama. */
    public boolean noHitAnimation = true;
    /** Ekrandaki title/subtitle yazilari gosterilmez. */
    public boolean noTitles = true;
    /** Zorla uygulanan render mesafesi (chunk). 0 = kapali. */
    public int forceViewDistance = 4;

    /** Zirh, pelerin, elytra, kafa itemi, saplanmis ok, omuz papagani, Deadmau5 kulagi cizilmez. */
    public boolean noEntityFeatures = true;
    /** Yerdeki item, ok, XP kuresi gibi canli olmayan varliklar icin cizim mesafesi (blok). */
    public int smallEntityDistance = 16;
    /** Cok uzaktaki varliklarin istemci tarafi tick'ini atla (CPU tasarrufu). */
    public boolean skipFarEntityTicks = true;
    public int farEntityTickDistance = 48;

    // Hesaplanmis degerler (dosyaya yazilmaz)
    public transient double entityDistanceSq;
    public transient double blockEntityDistanceSq;
    public transient double particleDistanceSq;
    public transient double smallEntityDistanceSq;
    public transient double farTickDistanceSq;

    public static FelixConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static synchronized void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("felixboost.json");
        FelixConfig cfg = null;
        if (Files.exists(path)) {
            try (Reader r = Files.newBufferedReader(path)) {
                cfg = GSON.fromJson(r, FelixConfig.class);
            } catch (Exception e) {
                FelixBoostClient.LOGGER.warn("felixboost.json okunamadi, varsayilanlar kullaniliyor", e);
            }
        }
        if (cfg == null) cfg = new FelixConfig();
        cfg.sanitize();
        try (Writer w = Files.newBufferedWriter(path)) {
            GSON.toJson(cfg, w);
        } catch (IOException e) {
            FelixBoostClient.LOGGER.warn("felixboost.json yazilamadi", e);
        }
        instance = cfg;
    }

    private void sanitize() {
        entityDistance = Math.max(16, entityDistance);
        blockEntityDistance = Math.max(16, blockEntityDistance);
        particleDistance = Math.max(8, particleDistance);
        particleKeepPercent = Math.min(100, Math.max(0, particleKeepPercent));
        entityDistanceSq = (double) entityDistance * entityDistance;
        blockEntityDistanceSq = (double) blockEntityDistance * blockEntityDistance;
        particleDistanceSq = (double) particleDistance * particleDistance;
        smallEntityDistance = Math.max(8, smallEntityDistance);
        farEntityTickDistance = Math.max(32, farEntityTickDistance);
        smallEntityDistanceSq = (double) smallEntityDistance * smallEntityDistance;
        farTickDistanceSq = (double) farEntityTickDistance * farEntityTickDistance;
    }
}
